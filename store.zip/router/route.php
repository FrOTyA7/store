<?php
class route{
	private static function parse($URL){
		if(0===preg_match_all('/{([^\/]+)}/', $URL, $matches)){
			if(strtolower($URL)===strtolower( trim(preg_replace('/\/+/', '/', $_SERVER['REQUEST_URI']),'/') )){
				return true;
			}else{
				return false;
			}
		}
		$data = $indexes = [];
		$i = 0;
		$_url = $_URL = '';
		$url = explode('/', strtolower( trim(preg_replace('/\/+/', '/', $_SERVER['REQUEST_URI']),'/') ));
		$URL = explode('/', strtolower($URL));
		foreach($URL as $index => $bit){
			if($bit!=="" && $bit[0]==='{'){
				$indexes[$index] = $matches[1][$i];
				$i++;
			}else{
				if(isset($url[$index])){
					$_url .= $url[$index];
				}else{
					return false;			
				}
				$_URL .= $URL[$index];
			}
		}
		if($_URL!==$_url){return false;}
		foreach ($indexes as $key => $value) {
			$data[$value] = ( isset($url[$key]) )? $url[$key] : null;
		}
		return $data;
	}
	static function GET($URL,$callback){
		if($_SERVER['REQUEST_METHOD'] === 'GET'){
			$data = SELF::parse($URL); 
			if($data !== false){
				if(gettype($callback)==='string'){
					$class = "\\controllers\\".$callback;
					new $class();
					die();
				}else{
					$callback($data);
					die();
				}
			}
		}
	}
	static function POST($_method,$data=[]){
		if($_SERVER['REQUEST_METHOD'] === 'POST'&& isset($_POST['method']) && empty($_FILES)){
			$data[] = 'method';
			if(strtolower($_method) !== strtolower($_POST['method']) ){return;}
			if(count($data) !== count($_POST)){return;}
			foreach ($data as $value) {
				if(!array_key_exists($value, $_POST)){
					return;
				}
			}
			$data_ = $_POST;
			unset($data_['method']);
			\controllers\POST::{$_POST['method']}($data_);
		}
		die();
	}
	static function END($URL){
		echo "<script>window.location='/".$URL."';</script>";
		die();
	}
}

