<?php 
require_once $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.'load.inc';
// ROUTE
// GET
ROUTE::GET('','main');
ROUTE::GET('Account/Login','login');
ROUTE::GET('Account/AddUser','addUser');
ROUTE::GET('Account/Setting','setting');
ROUTE::GET('Home/About','about');
ROUTE::GET('Home/Contact','contact');
ROUTE::GET('Home/Show_Data','showData');
ROUTE::GET('Home/Add_Data','addData');
ROUTE::END('');

// POST  addUser
ROUTE::POST('showData');
ROUTE::POST('logout');
ROUTE::POST('addUser',['user','pass','admin']);
ROUTE::POST('checkUser',['user']);
ROUTE::POST('checkPass',['pass']);
ROUTE::POST('update',['user','newPass','oldPass']);
ROUTE::POST('addData',['id','date','type','code','name','unit','quantity','note']);
ROUTE::POST('login',['user','pass']);
