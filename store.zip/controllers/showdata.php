<?php
namespace controllers;
class showData extends controll{
	function __construct(){
		session_start();
		if(!isset($_SESSION['permission'])){
			$this->go('/Account/Login');
		}
		$this->view('head',[
			'title'	=> 'Show Data - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission']),
			'dir' => 'rtl'
		]);
		$this->view('showData');
		$this->view('footer',[
			'postData' => true
		]);
	}
}