<?php
namespace controllers;
class main extends controll{
	function __construct(){
		session_start();
		$this->view('head',[
			'title'	=> 'Home Page - My PHP Application',
			'dir'	=>	'rtl',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('main');
		$this->view('footer',[
			'postData' => true,
			'alert' => true
		]);
	}
}