<?php
namespace controllers;
class addUser extends controll{
	function __construct(){
		session_start();
		if(!isset($_SESSION['permission'])){
			$this->go('/');
		}
		$this->view('head',[
			'title'	=> 'Add User - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('addUser');
		$this->view('footer',[
			'postData' => true,
			'alert' => true
		]);
	}
}