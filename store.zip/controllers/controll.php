<?php
namespace controllers;
class controll{
	public static $VAR = Array();
    public static function var($VAR){
        if($VAR==='PDO'){
            if(!isset(SELF::$VAR['PDO'])){
                try {
                    SELF::$VAR['PDO'] = new \PDO('mysql:dbname='.$GLOBALS['db_info']['dbname'].';host='.$GLOBALS['db_info']['host'].';charset=utf8mb4', $GLOBALS['db_info']['username'], $GLOBALS['db_info']['password']);
                } catch (\PDOException $e) {
                    var_dump($e);
                    die();
                }
            }
            return SELF::$VAR['PDO'];
        }
    }
	protected function view($view,$d=[]){
		$data = function($i)use($d){
			if(isset($d[$i])){
				return $d[$i];
			}else{
				return null;
			}
		};
		require_once $_SERVER['DOCUMENT_ROOT'].DS.'views'.DS.$view.'.php';
	}

	protected function cookie($method,$name,$value='null',$time=null){
		if($time===null){$time=time();}
		if($method==='set'){
			// cookie('set','lang','ar',2628000);
			setcookie($name,$value,time()+$time,'/');
			return 'set';
		}
		else if($method==='del'){
			// cookie('del','lang');
			setcookie($name,null,$time-1,'/');
			return 'del';
		}
		else if($method==='check'){
			// return true of false
			// cookie('check','lang','ar'); check if value is correct
			// cookie('check','lang'); check if exist
			if($value==='null'){
				return isset($_COOKIE[$name]);
			}
			if($_COOKIE[$name]===$value){
				return true;
			}else{
				return false;
			}
			
		}
		else if($method==='get'){
			// cookie('get','lang')
			return $_COOKIE[$name];
		}
	}

	protected function lang(){
		if($this->cookie('check','lang')){
			return $this->cookie('get','lang');
		}else{
			return 'ar';
		}
	}

	protected function go($URL){
		echo "<script>window.location='".$URL."'</script>";
		die();
	}
	
	

	
}