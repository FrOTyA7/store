<?php
namespace controllers;
class login extends controll{
	function __construct(){
		session_start();
		$logedin = isset($_SESSION['id']);
		if($logedin){
			$this->go('/');
		}
		$this->view('head',[
			'title'	=> 'Log in - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('login');
		$this->view('footer',[
			'postData' => true,
			'alert' => true
		]);
	}
}