<?php
namespace controllers;
class contact extends controll{
	function __construct(){
		session_start();
		$this->view('head',[
			'title'			=> 'Contact - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('contact');
		$this->view('footer');
	}
}