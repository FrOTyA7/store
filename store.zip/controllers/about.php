<?php
namespace controllers;
class about extends controll{
	function __construct(){
		session_start();
		$this->view('head',[
			'title'	=> 'About - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('about');
		$this->view('footer');
	}
}