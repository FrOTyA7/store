<?php
namespace controllers;
use \models\users;
use \models\data;
class POST extends controll{
	public static function login($data){
        $userArr = users::getByWhere('user="'.$data['user'].'"',1,[
        	'pass','permission','id'
        ],2);
        if(!empty($userArr)){
        	$userArr = $userArr[0];
        }else{
        	return;
        }
        if($userArr!==false){
            if($userArr['pass']===md5($data['pass'])){
            	session_start();
            	$_SESSION["id"] = $userArr['id'];
				if($userArr['permission']==1){
					$_SESSION["permission"] = 1;
				}
                echo 1;
            }
        }else{
            echo 0;
        }
	}
	public static function logout($data){
		session_start();
		if(isset($_SESSION['id'])){
			session_destroy();
			SELF::go('/');
			SELF::go('/');
		}
	}
	public static function showData($data){
		session_start();
		if(isset($_SESSION['id'])){
			echo json_encode(data::getByWhere('1',9999,[],3));
		}
	}
	public static function addData($data){
		session_start();
		if(isset($_SESSION['id'])){
			new data($data['id'],$data['date'],$data['type'],$data['code'],$data['name'],$data['unit'],$data['quantity'],$data['note'],function($state){
				if($state['exec'] !== false && $state['error']===null ){
					echo 1;
				}else{
					echo 0;
				}
			});
		}else{
			echo 'log';
		}
	}
	public static function addUser($data){
		session_start();
		if(isset($_SESSION['permission'])){
			new users(0,$data['user'],md5($data['pass']),$data['admin'],function($state){
				if($state['exec'] !== false && $state['error']===null ){
					echo 1;
				}else{
					echo 0;
				}
			});
		}
	}
	public static function checkUser($data,$php=0){
		if(!$php){
			session_start();
		}
		if(isset($_SESSION['id'])){
            if(users::unique('user',$data['user'])){
				if(!$php){
					echo 1;
				}else{
					return 1;
				}
            }else{
				if(!$php){
                	echo 0;
				}else{
					return 0;
				}
            }
		}
	}
	public static function checkPass($data){
		session_start();
		if(isset($_SESSION['id'])){
			$obj = users::getByPK($_SESSION['id'],['pass']);
            if($obj->pass === md5($data['pass'])){
                echo 1;
            }else{
                echo 0;
            }
		}
	}
	public static function update($data){
		session_start();
		if(isset($_SESSION['id'])){
			$obj = users::getByPK($_SESSION['id'],['pass']);
            if($obj->pass===md5($data['oldPass'])&&SELF::checkUser(['user'=>$data['user']],1)){
            	$obj->user = $data['user'];
            	$obj->pass = md5($data['newPass']);
                echo 1;
            }else{
                echo 0;
            }
		}
	}
}