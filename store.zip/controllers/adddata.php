<?php
namespace controllers;
class addData extends controll{
	function __construct(){
		session_start();
		if(!isset($_SESSION['permission'])){
			$this->go('/Account/Login');
		}
		$this->view('head',[
			'title'	=> 'Add Data - My PHP Application',
			'logedin' => isset($_SESSION['id']),
			'permission' => isset($_SESSION['permission'])
		]);
		$this->view('addData');
		$this->view('footer',[
			'postData' => true,
			'alert' => true
		]);
	}
}