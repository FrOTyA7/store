CREATE TABLE `users` (
	`id`	INT  UNSIGNED NOT NULL AUTO_INCREMENT ,
	`user`	VARCHAR(20) UNIQUE NOT NULL ,
	`pass`	CHAR(32) NOT NULL ,
	`permission` TINYINT(1) NOT NULL ,
PRIMARY KEY (`id`)
)ENGINE = InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

CREATE TABLE `data` (
`id` 	INT UNSIGNED NOT NULL AUTO_INCREMENT ,
`date`	DATE NOT NULL ,
`type`	VARCHAR(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL ,
`code`	SMALLINT UNSIGNED NOT NULL ,
`name`	VARCHAR(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL ,
`unit`	VARCHAR(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL ,
`quantity` SMALLINT UNSIGNED NOT NULL ,
`note`	VARCHAR(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL ,
PRIMARY KEY (`id`)
) ENGINE = InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

INSERT INTO users SET id=1, user='admin', pass=MD5('admin'), permission=1;