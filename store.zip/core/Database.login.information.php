<?php
return [
//	Type your DataBase information Here!
	'host' => 'localhost',
	'username' 	=> 'root',
	'password' 	=> '',
	'dbname'	=>	'ra'
];