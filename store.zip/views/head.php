<!DOCTYPE html>
<html dir="<?= $data('dir') ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $data('title') ?></title>
    <link href="/css/bootstrap.css" rel="stylesheet">
	<link href="/css/site.css" rel="stylesheet">
    <script src="/js/modernizr-2.6.2.js"></script>
</head>
<body>
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">Application name</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li><a href="/">Home</a></li>
                    <li><a href="/Home/About">About</a></li>
                    <li><a href="/Home/Contact">Contact</a></li>
                </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="/Account/Setting" id="settingLink"></a>
                        </li>
                        <li>
                            <a href="/Account/AddUser" id="addLink"></a>
                        </li>
                        <li>
                            <a href="/Account/Login" id="loginLink"></a>
                        </li>
                    </ul>
            </div>
        </div>
    </div>
<script>
document.addEventListener(`DOMContentLoaded`,function(){
    var logedin = <?= $data('logedin')?'true':'false' ?>;
    var permission = <?= $data('permission')?'true':'false' ?>;
    if(logedin){
        $('#loginLink')
         .html(`Log out`)
         .attr(`href`,``)
         .on(`click`,function(){
            postData({
                method: `logout`
            }).then(r=>{
                if(r==0){
                    alert(`Error`)
                }else{
                    window.location = `/`
                }
            });
         });
        $('#settingLink')
         .html(`setting`)
    }else{
        $('#loginLink')
         .html(`Log in`)
    }
    if(permission){
        $('#addLink').html(`Add User`);
    }
});
</script>