<div class="container body-content">
    <div style="
    position: fixed;
    border-radius: 21px;
    font-size: 40px;
    background-color: #222222;
    color: #fff;
    padding: 15px;
    text-align: center;
    opacity: 0;
    top: 60px;
    "id="alert"></div>
    <h2 style="text-align:center;">إضافة طلب صرف</h2>
    <form>
        <hr />
        <div class="form-group">
            <label class="control-label col-md-2" for="SarfNum">SarfNum</label>
            <input class="form-control" data-val="true" data-val-number="The field SarfNum must be a number." data-val-required="The SarfNum field is required." id="SarfNum" name="SarfNum" type="number" value="" />
            <span class="field-validation-valid" data-valmsg-for="SarfNum" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="Date">Date</label>
            <input class="form-control" data-val="true" placeholder="YYYY-MM-DD" data-val-date="The field Date must be a date." data-val-required="The Date field is required." id="Date" name="Date" type="datetime" value="" />
            <span class="field-validation-valid" data-valmsg-for="Date" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="Type">Type</label>
            <input class="form-control" id="Type" name="Type" type="text" value="" />
            <span class="field-validation-valid" data-valmsg-for="Type" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="ID_Stndrd_Item">ID_Stndrd_Item</label>
            <input class="form-control" data-val="true" data-val-number="The field ID_Stndrd_Item must be a number." data-val-required="The ID_Stndrd_Item field is required." id="ID_Stndrd_Item" name="ID_Stndrd_Item" type="number" value="" />
            <span class="field-validation-valid" data-valmsg-for="ID_Stndrd_Item" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="ItemName">ItemName</label>
            <input class="form-control" id="ItemName" name="ItemName" type="text" value="" />
            <span class="field-validation-valid" data-valmsg-for="ItemName" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="Unit">Unit</label>
            <input class="form-control" id="Unit" name="Unit" type="text" value="" />
            <span class="field-validation-valid" data-valmsg-for="Unit" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="Quantity">Quantity</label>
            <input class="form-control" data-val="true" data-val-number="The field Quantity must be a number." data-val-required="The Quantity field is required." id="Quantity" name="Quantity" type="text" value="" />
            <span class="field-validation-valid" data-valmsg-for="Quantity" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="Notes">Notes</label>
            <input class="form-control" id="Notes" name="Notes" type="text" value="" />
            <span class="field-validation-valid" data-valmsg-for="Notes" data-valmsg-replace="true"></span>
        </div>

        <div class="form-group">
            <label class="control-label col-md-2" for="submit"></label>
            <input id="submit" type="submit" value="إضافة الطلب" class="btn btn-primary" />
        </div>
        </div>
    </form>
</div>
<script>
function ok(){
    let arr = value(1).split(`-`);
    if(arr.length!=3||isNaN(parseInt(arr[0]))||isNaN(parseInt(arr[1]))||isNaN(parseInt(arr[2]))){
        return 1//alert(error)
    }else{
        document.getElementById(`Date`).value = parseInt(arr[0])+`-`+parseInt(arr[1])+`-`+parseInt(arr[2])
    }
    for(let i=1;i<7;i++){
        if(value(i)==``){
            return i
        }
    }
    return true;
}
var value = id => document.getElementById(value.data[id]).value
value.data = [`SarfNum`,`Date`,`Type`,`ID_Stndrd_Item`,`ItemName`,`Unit`,`Quantity`,`Notes`]
document.getElementsByTagName(`form`)[0].addEventListener(`submit`,function(e){
    e.preventDefault();
    let Ok = ok()
    if(Ok!==true){
        console.log(Ok)
        alert(`Not Valid `+document.querySelector(`[for="`+value.data[Ok]+`"]`).innerText);
        return
    }
    postData({
        method: `addData`,
        id: value(0),
        date: value(1),
        type: value(2),
        code: value(3),
        name: value(4),
        unit: value(5),
        quantity: value(6),
        note: value(7)
    }).then(r=>{
        if(r==1){
            alert(`Item added successfully`)
        }else
        if(r===`log`){
            alert(`Login first`)
            setTimeout(function(){
                window.location = `/Account/Login`
            },2000)
        }
        else{
            alert(`Error`)
        }
    });
})
</script>