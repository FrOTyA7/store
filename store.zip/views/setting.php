    <div class="container body-content">
<h2>Setting</h2>
<form class="form-horizontal">
    <hr />
    <div class="form-group">
        <label class="col-md-2 control-label" for="UserName">User name</label>
        <div class="col-md-10">
            <input class="form-control" id="UserName" type="text" />
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="Password">Old Password</label>
        <div class="col-md-10">
            <input class="form-control" id="OldPassword" type="password" />
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="ConfirmPassword">New password</label>
        <div class="col-md-10">
            <input class="form-control" id="NewPassword"  type="password" />
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="ConfirmPassword">Confirm password</label>
        <div class="col-md-10">
            <input class="form-control" id="ConfirmPassword" type="password" />
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-offset-2 col-md-10">
            <input type="submit" class="btn btn-default" value="Confirm" />
        </div>
    </div>
</form>
<script>
document.addEventListener(`DOMContentLoaded`,function(){
    let user;
    let oldPass;
    let pass1;
    let pass2;
    let checkUser = () =>{
        let ret = postData({
            method: `checkUser`,
            user: user
        });
        ret.then(r=>{
            if(r==0){
                alert(`username unavailable`)
            }
        });
        return ret;
    }
    let checkPass = () =>{
        let ret = postData({
            method: `checkPass`,
            pass: oldPass
        });
        ret.then(r=>{
            if(r==0){
                alert(`incorrect password`)
            }
        });
        return ret;
    }
    let ok = async function(){
        if(pass1===pass2 && await checkUser() && await checkPass() && user.length>2 ){
            return true;
        }
        return false;
    }
    document.getElementsByTagName('form')[0].addEventListener(`submit`,e=>{
        e.preventDefault();
        user = document.getElementById(`UserName`).value;
        oldPass = document.getElementById(`OldPassword`).value;
        pass1 = document.getElementById(`NewPassword`).value;
        pass2 = document.getElementById(`ConfirmPassword`).value;
        ok().then(r=>{
            if(r){
                postData({
                    method: `update`,
                    user: user,
                    oldPass: oldPass,
                    newPass: pass1
                }).then(r=>{
                    if(r!=0){
                        alert(`Information updated successfully`)
                    }
                });
            }
        });
    });
});
</script>