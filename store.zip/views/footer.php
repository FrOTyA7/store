    </div>
<footer style="text-align: center;">
    <hr>
    <p>© 2019 - My PHP Application</p>
</footer>
</body>
<script src="/js/jquery-1.10.2.js"></script>
<script src="/js/bootstrap.js"></script>
<script src="/js/respond.js"></script>
<style>
    #alert{
        position: fixed;
        border-radius: 21px;
        font-size: 40px;
        background-color: #222222;
        color: #fff;
        padding: 15px;
        text-align: center;
        opacity: 0;
        top: 60px;
    }
</style>
<script>
<?php
	if($data('postData')){
?>
/*`*`*-------------*`*`*/
function postData(data = {}, url = `/`){
    return fetch(url, {
        method: "POST",
        cache: "no-cache",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: (new URLSearchParams(data)).toString()
    }).then(r=> r.text() );
}
/*`*`*-------------*`*`*/
<?php
	}
	if($data('alert')){
?>
/*`*`*-------------*`*`*/
function alert(msg){
    let node = document.createElement(`div`);
    node.id = `alert`;
    document.querySelector(`div.container.body-content`).insertAdjacentElement(`beforeEnd`,node)
    node.innerHTML = msg;
    setTimeout(function(){
        node.style.left = "calc( 50% - "+node.offsetWidth/2+"px)";
        node.style.display = `none`
        node.style.opacity = 100;
        $(node).fadeIn();
        setTimeout(function(){
            $(node).fadeOut();
            setTimeout(function(){
                node.remove()
            },1000)
        },2000)
    },100)
}
/*`*`*-------------*`*`*/
<?php
	}
?>
</script>
</html>