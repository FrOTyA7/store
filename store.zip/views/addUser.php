    <div class="container body-content">
<h2>Add User</h2>
<form class="form-horizontal">
    <hr />
    <div class="validation-summary-valid" data-valmsg-summary="true">
        <ul>
            <li style="display:none"></li>
        </ul>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="UserName">User name</label>
        <div class="col-md-10">
            <input class="form-control" data-val="true" data-val-required="The User name field is required." id="UserName" name="UserName" type="text" value="" />
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="Password">Password</label>
        <div class="col-md-10">
            <input class="form-control" data-val="true" data-val-length="The Password must be at least 6 characters long." data-val-length-max="100" data-val-length-min="6" data-val-required="The Password field is required." id="Password" name="Password" type="password" />
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-2 control-label" for="ConfirmPassword">Confirm password</label>
        <div class="col-md-10">
            <input class="form-control" data-val="true" data-val-equalto="&#39;Confirm password&#39; and &#39;Password&#39; do not match." data-val-equalto-other="*.Password" id="ConfirmPassword" name="ConfirmPassword" type="password" />
        </div>
    </div>
    <div class="form-group">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" style="margin: 10px 0px 0px 15px;" id="Admin">
            <label class="col-md-2 control-label" for="Admin">
            Admin ?
            </label>
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-offset-2 col-md-10">
            <input type="submit" class="btn btn-default" value="Add User" />
        </div>
    </div>
</form>
<script>
document.addEventListener(`DOMContentLoaded`,function(){
    let user;
    let pass1;
    let pass2;
    let admin;
    let checkUser = async function(){
        let r = await postData({
            method: `checkUser`,
            user: user
        });
        if(r==0){
            alert(`user not available !`)
            return 0
        }
        return 1
    }
    let ok = async function(){
        if(pass1===pass2&& await checkUser()&&user.length>2){
            return true;
        }
        return false;
    }
    document.getElementsByTagName('form')[0].addEventListener(`submit`,e=>{
        e.preventDefault();
        user = document.getElementById(`UserName`).value;
        pass1 = document.getElementById(`Password`).value;
        pass2 = document.getElementById(`ConfirmPassword`).value;
        admin = document.getElementById(`Admin`).checked?`1`:`0`
        ok().then(r=>{
            if(r){
                postData({
                    method: `addUser`,
                    user: user,
                    pass: pass1,
                    admin: admin
                }).then(r=>{
                    if(r==0){
                        alert(`Error`)
                    }else{
                        alert(`user added successfully`)
                    }
                });
            }
        });
    });
});
</script>