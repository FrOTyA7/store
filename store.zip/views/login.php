<div class="container body-content">
<h2>Log in.</h2>
<div class="row">
    <div class="col-md-8">
        <section id="loginForm">
<form class="form-horizontal">
    <h4>Use a local account to log in.</h4>
                <hr />
                <div class="form-group">
                    <label class="col-md-2 control-label" for="UserName">User name</label>
                    <div class="col-md-10">
                        <input class="form-control" data-val="true" data-val-required="The User name field is required." id="UserName" name="UserName" type="text" value="" />
                        <span class="field-validation-valid" data-valmsg-for="UserName" data-valmsg-replace="true"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2 control-label" for="Password">Password</label>
                    <div class="col-md-10">
                        <input class="form-control" data-val="true" data-val-required="The Password field is required." id="Password" name="Password" type="password" />
                        <span class="field-validation-valid" data-valmsg-for="Password" data-valmsg-replace="true"></span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-offset-2 col-md-10">
                        <input type="submit" value="Log in" class="btn btn-default" />
                    </div>
                </div>
</form>        </section>
    </div>
</div>
<script>
document.addEventListener(`DOMContentLoaded`,function(){
    document.getElementsByTagName('form')[0].addEventListener(`submit`,e=>{
        e.preventDefault();
        postData({
            method: `login`,
            user: document.getElementById(`UserName`).value,
            pass: document.getElementById(`Password`).value
        }).then(r=>{
            if(r==0){
                alert(`username or password is incorrect`);
            }else{
                window.location = `/`
            }
        });
    })
});
</script>