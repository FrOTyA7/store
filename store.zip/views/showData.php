        <div class="jumbotron">
            <h2 class="btn-block">طلبات الصرف</h2>
            <div class="table-responsive">
                <table  class="table table-striped table-bordered table-hover table-condensed">
                    <thead>
                        <tr>
                            <th>
                                رقم الطلب
                            </th>
                            <th>
                                التاريخ
                            </th>
                            <th>
                                نوع الكشف
                            </th>
                            <th>
                                كود البند
                            </th>
                            <th>
                                اسم البند
                            </th>
                            <th>
                                وحدة القياس
                            </th>
                            <th>
                                الكمية
                            </th>
                            <th>
                                ملاحظات
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
<script>
document.addEventListener(`DOMContentLoaded`,function(){
    postData({
        method: `showData`
    }).then(r=>{
        r = JSON.parse(r);
        if(r!=undefined){
            renderTable(r);
        }
    });
});
function renderTable(rows){
    for(row of rows){
        document.getElementsByTagName(`tbody`)[0].insertAdjacentHTML(`beforeend`, `<tr><td>`+row[0]+`</td><td>`+row[1]+`</td><td>`+row[2]+`</td><td>`+row[3]+`</td><td>`+row[4]+`</td><td>`+row[5]+`</td><td>`+row[6]+`</td><td>`+row[7]+`</td></tr>`);
    }
}
</script>