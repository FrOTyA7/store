    <div class="container body-content">
    <div class="jumbotron">
        <h1> الصفوة للتطوير العمرانى</h1>
        <p class="lead">هنا يمكنك  إدارة المواقع من خلال برنامج إدارة المخازن والمشتريات وكذلك عمل مستخلصات المقاولين</p>

        <p><a href="/Home/Show_Data" class="btn btn-primary btn-large">التعرف على المزيد »</a></p>
    </div>
    <div class="row">
        <div class="col-md-4">
            <h2>إدارة المخازن</h2>
            <p>
                هنا يمكنك الدخول على موديول المخازن والتعرف على كيفية تعريف ألأصناف وعمل أذون إضافة المخزن 
            </p>
            <p><a style="background-color:forestgreen" class="btn btn-primary btn-large" href="/Home/Add_Data">عرض المزيد »</a></p>
        </div>
        <div class="col-md-4">
            <h2>إدارة المشتريات</h2>
            <p>هنا يمكنك عمل فواتير المشتريات من خلال تطبيق المشتريات والتعرف على حسابات الموردين</p>
            <p><a style="background-color:forestgreen" class="btn btn-primary btn-large" href="/Home/Show_Data">عرض المزيد »</a></p>
        </div>
        <div class="col-md-4">
            <h2>المستخلصات</h2>
            <p>هنا يمكنك عمل فواتير مستخلصات المقاولين من خلال تطبيق المستخلصات والتعرف على حسابات مراكز التكلفة وماتم انجازه لكل وحدة</p>
            <p><a style="background-color:forestgreen" class="btn btn-primary btn-large" href="/Home/Show_Data">عرض المزيد »</a></p>
        </div>
    </div>
