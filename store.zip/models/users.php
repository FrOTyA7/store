<?php namespace models;
class users extends sync{
    protected const PK = 'id';
    protected $id;
    protected $user;
    protected $pass;
    protected $permission;
}