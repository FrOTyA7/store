<?php namespace models;
class data extends sync{
    protected const PK = 'id';
    protected $id;
    protected $date;
    protected $type;
    protected $code;
    protected $name;
    protected $unit;
    protected $quantity;
    protected $note;
}