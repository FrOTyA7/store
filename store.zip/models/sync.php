<?php namespace models;
class sync{
    private static $VAR = Array();
    public static function Free($query){
        $result = SELF::var('PDO')->query($query);
        if($result!==false){
            return $result->fetchall(\PDO::FETCH_ASSOC);
        }
        return false;
    }
    public static function checkLimit($s){
        if(filter_var($s, FILTER_VALIDATE_INT)!==false){return true;}
        $s = explode(',', $s);
        if(count($s)!==2){return false;}
        if(filter_var($s[0], FILTER_VALIDATE_INT)===false){return false;}
        if(filter_var($s[1], FILTER_VALIDATE_INT)===false){return false;}
        return true;
    }
    private static function var($VAR){
        if($VAR==='PDO'){
            if(!isset(SELF::$VAR['PDO'])){
                try {
                    SELF::$VAR['PDO'] = new \PDO('mysql:dbname='.$GLOBALS['db_info']['dbname'].';host='.$GLOBALS['db_info']['host'].';charset=utf8mb4', $GLOBALS['db_info']['username'], $GLOBALS['db_info']['password']);
                } catch (\PDOException $e) {
                    var_dump($e);
                    die();
                }
            }
            return SELF::$VAR['PDO'];
        }elseif($VAR==='CLASS'){                        //Here
            return (strlen(__NAMESPACE__)===0)?get_called_class():substr(get_called_class(),strlen(__NAMESPACE__)+1);
        }
    }
    public function __construct(){
        if(empty(func_get_args())){return false;}
        $i = 0 ;
        $vars = get_object_vars($this);
        foreach($vars as $name => $val){
            $this->$name = func_get_arg($i);
            $i++;
        }
        $callback =  func_get_arg($i);
        $this->create($callback);
    }
    private function create($callback){
        $query = 'INSERT INTO '.SELF::var('CLASS').' SET ';
        $vars = get_object_vars($this);
        foreach($vars as $name => $val){
            if(gettype($this->$name)==='string'){           
                $this->$name = str_replace("\\","\\"."\\",$this->$name);                                                    //here
                $this->$name = str_replace("'","\\'",$this->$name);
                $query .= "{$name}='{$this->$name}',";
            }elseif($this->$name===null){
                $query .= "{$name}=null,";
            }else{
                $query .= "{$name}={$this->$name},";
            }
        }
        $query[strlen($query)-1] = ';';
        if(!defined(get_called_class().'::PK')){                   //here
            $state['exec'] = SELF::var('PDO')->exec($query);
            $state['error'] = null;
            if($state['exec']===false){
                $state['error'] = SELF::var('PDO')->errorInfo();
            }
            $callback($state);
            return;
        }
        $state['exec'] = SELF::var('PDO')->exec($query);
        $this->{STATIC::PK} = SELF::var('PDO')->lastInsertId();     //here
        $state['error'] = null;
        if($state['exec']===false){
            $state['error'] = SELF::var('PDO')->errorInfo();
            $minPK = SELF::var('PDO')->query('SELECT MIN('.STATIC::PK.') FROM '.SELF::var('CLASS').';')->fetch(\PDO::FETCH_NUM)[0];
            SELF::var('PDO')->exec('ALTER TABLE '.SELF::var('CLASS').' AUTO_INCREMENT = '.$minPK.';');
        }
        $callback($state);
    }
    static function getByPK($id,$data=[]){
        if(empty($data)){
            if(gettype($id)==='string'){
                $id = str_replace("\\","\\"."\\",$id);                                                    //here
                $id = str_replace("'","\\'",$id);
                $pk = "'".$id."'";
            }else{
                $pk = $id;
            }
            $query = "SELECT * FROM ".SELF::var('CLASS')." WHERE ".STATIC::PK." = {$pk};";
        }else{
            if(gettype($id)==='string'){
                $pk = "'".$id."'";
            }else{
                $pk = $id;
            }
            $query = "SELECT ".join(',',$data)." FROM ".SELF::var('CLASS')." WHERE ".STATIC::PK." = {$pk};";
        }
        $stm = SELF::var('PDO')->query($query);
        if($stm !== false){
            $stm->setFetchMode(\PDO::FETCH_CLASS,get_called_class());            //here
            $ret =  $stm->fetch();
            if($ret !== false){
                $ret->{STATIC::PK} = $id;
                return $ret;
            }
        }
        //echo $query;
        return false;
    }
    static function getByWhere($where,$limit,$data=[],$mod=2){             // Here
        // PDO::FETCH_ASSOC     === 2
        // PDO::FETCH_NUM       === 3
        if(!SELF::checkLimit($limit)){return false;}
        if(empty($data)){
            $query  = "SELECT * FROM ".SELF::var('CLASS')." WHERE {$where} LIMIT {$limit};";
            $stm    = SELF::var('PDO')->query($query);
            if($stm !== false){
                return $stm->fetchall($mod);
            }
            return false;
        }else{
            $query  = "SELECT ".join(',',$data)." FROM ".SELF::var('CLASS')." WHERE {$where} LIMIT {$limit};";
            $stm    = SELF::var('PDO')->query($query);
            if($stm !== false){
                //echo $query;
                return $stm->fetchall($mod);
            }
            //echo $query;
            return false;
        }
    }
    static function unique($unique,$val){
        if(gettype($val)==='string'){
            $val = str_replace("\\", "\\"."\\", $val);
            $val = str_replace("'", "\\'", $val);                        // in all
            $pk = "'".$val."'";
        }else{
            $pk = $val;
        }
        $query = SELF::var('PDO')->query("SELECT '' from ".SELF::var('CLASS')." where ".$unique."=".$pk.";")->fetch(\PDO::FETCH_NUM);
        if($query === false){
            return true;
        }
        else{
            return false;
        }
    }
    public function __set($var,$val){
        if(array_key_exists($var,get_object_vars($this))){
            if(gettype($this->{STATIC::PK})==='string'){
                $pk = "'".$this->{STATIC::PK}."'";
            }else{
                $pk = $this->{STATIC::PK};
            }
            if(gettype($val)==='string'){
                $val = str_replace("\\","\\"."\\",$val);     // firest !importamt
                $val = str_replace("'","\\'",$val);          // second important                                // here
                $query = "UPDATE ".SELF::var('CLASS')." SET {$var} = '{$val}' WHERE ".STATIC::PK."=".$pk.';';
            }elseif(gettype($val)===null){
                $query = "UPDATE ".SELF::var('CLASS')." SET {$var} = null WHERE ".STATIC::PK."=".$pk.';';
            }else{
                $query = "UPDATE ".SELF::var('CLASS')." SET {$var} = {$val} WHERE ".STATIC::PK."=".$pk.';';
            }
            if(SELF::var('PDO')->exec($query)!==false){
                $this->$var = $val;
            }else{
                $this->$var = 'fail';
            }
        }
    }
    public function __get($var){
        if(!array_key_exists($var,get_object_vars($this))){
            return false;
        }else{
            if($this->$var === null){
                if(gettype($this->{STATIC::PK})==='string'){
                    $pk = "'".$this->{STATIC::PK}."'";
                }else{
                    $pk = $this->{STATIC::PK};
                }
                $query = "SELECT {$var} FROM ".SELF::var('CLASS')." WHERE ".STATIC::PK."=".$pk.";";
                //echo $query;
                $this->$var = SELF::var('PDO')->query($query)->fetch(\PDO::FETCH_NUM)[0];
                return $this->$var; 
            }else{
                return $this->$var;
            }
        }
    }
    public function delete(){
        if(gettype($this->{STATIC::PK})==='string'){
            $pk = "'".$this->{STATIC::PK}."'";
        }else{
            $pk = $this->{STATIC::PK};
        }
        $query = "DELETE FROM ".SELF::var('CLASS')." WHERE ".STATIC::PK."=".$pk.';';
        if(SELF::var('PDO')->exec($query) !== false){
            return true;
        }
        return false;
    }
    static function deleteByPK($id){
        if(gettype($id)==='string'){
            $id = str_replace("\\","\\"."\\",$id);                                                    //here
            $id = str_replace("'","\\'",$id);
            $pk = "'".$id."'";
        }else{
            $pk = $id;
        }
        $query = "DELETE FROM ".SELF::var('CLASS')." WHERE ".STATIC::PK."=".$pk.';';
        if(SELF::var('PDO')->exec($query) !== 0){
            return true;
        }
        return false;
    }
    static function deleteByWhere($where){
        $query = "DELETE FROM ".SELF::var('CLASS')." WHERE {$where} ;";
        //echo $query;
        return SELF::var('PDO')->exec($query);
    }
    static function updateByWhere($data,$where){
        $set = '';
        foreach($data as $key => $val){ // key="val",
            if(gettype($val)==='string'){
                $val = str_replace("\\","\\"."\\",$val);     // firest !importamt
                $val = str_replace("'","\\'",$val);          // second important                                // here
                $set .= $key."='".$val."',";
            }
            elseif(gettype($val)===null){
                $set .= $key."=null,";
            }
            else{
                $set .= $key."=".$val.",";
            }
        }
        $set = substr($set, 0, -1);
        $query = "UPDATE ".SELF::var('CLASS')." SET {$set} WHERE {$where};";
        //echo $query;
        return SELF::var('PDO')->exec($query);
    }
}
// WHERE {$where} is your responsibility